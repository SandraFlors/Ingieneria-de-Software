package flores_ingieneriatest;

public class Cuenta {
    int numCuenta;
    double saldo = 2000;
    
    
    public Cuenta(double saldoInicial) {
        this.saldo = saldoInicial;
    }
    
  
    public double retirarDinero(double monto) throws Exception {
        if (monto > saldo) {
            throw new Exception("OJO! no hay saldo suficiente!");
        } else {
            this.saldo -= monto; 
        }
        return saldo;
    }
    
  
    public void depositarDinero(Cuenta c, double monto) {
        if (c != null) {
            c.saldo += monto;
        }
    }
    
 
    public void transferirDinero(Cuenta c, double monto) throws Exception {
        this.retirarDinero(monto);
        depositarDinero(c, monto);
    }
    

    public boolean tieneSaldo() {
        return saldo > 0;
    }

   
    public boolean CuentasDiferentes(Cuenta c2) {
        return !this.equals(c2); 
    }


    public double convertirMoneda(String cotizacion) {
     
        return this.saldo / Double.parseDouble(cotizacion);
    }

  
    public void OperacionTildada(int mili) {
        try {
            Thread.sleep(mili); 
            System.out.println("El tiempo de operación es coherente");
        } catch (InterruptedException ex) {
            System.out.println("¡Tiempo de espera excedido! " + mili + " milisegundos");
        }
    }

 
    public double getSaldo() {
        return saldo;
    }
}

