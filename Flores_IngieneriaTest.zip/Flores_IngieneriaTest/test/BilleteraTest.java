import flores_ingieneriatest.Cuenta;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.time.Month;

public class BilleteraTest {


    private static int i = 0; 
    private Cuenta cuenta1; 

  
    @BeforeAll
    public static void beforeAll() {
        
        System.out.println("Fecha de hoy: " + LocalDate.of(2024, Month.DECEMBER, 13));
    }

   
    @AfterAll
    public static void afterAll() {
        System.out.println("FIN de la transacción");
    }

    @BeforeEach
    public void beforeEach() {
        cuenta1 = new Cuenta(1000.0); 
    }

   
    @AfterEach
    public void afterEach() {
        i++;
        System.out.println("Transaccion " + i + "> La cuenta quedó con " + cuenta1.getSaldo());
    }

    
    @Test
    public void testTransferenciaInvalida() {
        Cuenta cuenta2 = null;
        assertThrows(NullPointerException.class, () -> {
            cuenta1.transferirDinero(cuenta2, 100); 
        });
    }

   
    @Test
    public void testRetirarDinero() {
        assertThrows(Exception.class, () -> {
            cuenta1.retirarDinero(5000.0); 
        });
    }


    @Test
    public void testDepositarDinero() {
        cuenta1.depositarDinero(cuenta1, 200.0); 
        assertNotNull(cuenta1); 
        assertEquals(1200.0, cuenta1.getSaldo(), 0.1); 
    }


    @Test
    public void testDolarMEP1() {
        String monto = "300";
        double montoConvertido = cuenta1.convertirMoneda(monto);
        assertEquals(3.33, montoConvertido, 0.1); 
    }

    
    @Test
    public void testDolarMEP2() {
        String monto = "300 U$S";
        assertThrows(NumberFormatException.class, () -> {
            cuenta1.convertirMoneda(monto); 
        });
    }
}